## History

- v1.2.1 October 21, 2012
	- Workaround for Safari 6
		- Closes [#8](https://github.com/balupton/jquery-scrollto/issues/8) thanks to [Cameron Spear](https://github.com/CWSpear), [Dhruv Bhatia](https://github.com/dhruv-bhatia), [Fabricio Quagliariello](https://github.com/fmquaglia) for their help

- v1.2.0 July 2, 2012
	- Added `onlyIfOutside` option

- v1.1.0 July 2, 2012
	- Added `offsetTop` and `offsetLeft` options
	- Fixed firefox body scroll issue
	- Added horizontal scrolling
	- Closes 2, 3, 5, 6, 7

- v1.0.2 July 2, 2012
	- Coding standards update
	- Fixed global leak

- v1.0.1-beta August 31, 2010
	- Fixed body scrolling in IE

- v1.0.0-beta August 28, 2010
	- Initial Released Version

- v0.1.0-dev August 27, 2010
	- Initial Development Version
