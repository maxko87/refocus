## jQuery ScrollTo

Smooth Scrolling to any jQuery/DOM Element


## Usage

Refer to the [demo](http://balupton.github.com/jquery-scrollto/demo/) for usage instructions


## History

You can discover the history inside the [History.md](https://github.com/balupton/jquery-scrollto/blob/master/History.md#files) file


## License

Licensed under the incredibly [permissive](http://en.wikipedia.org/wiki/Permissive_free_software_licence) [MIT License](http://creativecommons.org/licenses/MIT/)
<br/>Copyright &copy; 2010-2012 [Benjamin Arthur Lupton](http://balupton.com)


## Contributors

- [Benjamin Lupton](http://github.com/balupton)
- [Capi Etheriel](https://github.com/barraponto)
- [David Šabata](https://github.com/david-sabata)
- [pshizzle](https://github.com/pshizzle)
- [meenie](https://github.com/meenie)
